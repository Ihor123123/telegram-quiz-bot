# Telegram Quiz Bot

## Overview

This is a Telegram bot application designed to help users practice and test their knowledge of exam question numbers. The bot presents questions from two categories (Specialty and Direction) and tracks user performance with statistics and streak tracking. Users can take quizzes in different modes and monitor their progress over time.

**Current Status**: ✅ Fully operational with intuitive button-based interface
**Bot Token**: 7755200969:AAEOXtp9_Uup3WQGBte4piCBH2xQoLyKQS8

## Recent Changes

**July 18, 2025**:
- Fixed library compatibility issue by downgrading to python-telegram-bot==20.7
- Successfully deployed working Telegram quiz bot
- Implemented complete button-based interface (no commands needed)
- Added comprehensive Russian language interface
- Integrated streak tracking and record management system
- Added 3-lives system with visual hearts display (❤️🖤)
- Implemented game over functionality with final statistics
- Added database migration for lives_left column
- Improved interface: removed duplicate buttons from answer feedback messages
- Made question text bold for better readability
- Changed lives icon to 🔥 to reduce visual distraction
- Optimized lives display: shows only in answer results, not in question screens

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modular Python architecture for a Telegram bot with the following key characteristics:

**Bot Framework**: Built using the `python-telegram-bot` library for handling Telegram API interactions
**Database**: SQLite for local data persistence
**Language**: Russian interface for user interaction
**Deployment**: Designed to run as a long-polling Telegram bot application

## Key Components

### 1. Main Application (`main.py`)
- **Purpose**: Entry point and bot configuration
- **Responsibilities**: 
  - Bot token management (environment variable with fallback)
  - Handler registration for commands, callbacks, and messages
  - Application lifecycle management
  - Error handling setup

### 2. Database Layer (`database.py`)
- **Technology**: SQLite with context managers for connection handling
- **Schema**: Single `users` table tracking:
  - User identification (user_id, username, first_name)
  - Performance metrics (current_streak, best_streak, total_questions, correct_answers)
  - Quiz state (quiz_mode, last_question_number, last_question_source)
- **Design Pattern**: Context manager for database connections to ensure proper resource cleanup

### 3. Message Handlers (`handlers.py`)
- **Purpose**: Business logic for bot interactions
- **Key Features**:
  - Welcome and help commands
  - Quiz mode selection and management
  - Answer processing and validation
  - Statistics display
  - State management during active quizzes

### 4. User Interface (`keyboards.py`)
- **Technology**: Telegram inline keyboards
- **Design**: Hierarchical menu system with:
  - Main menu (start quiz, statistics, help)
  - Quiz mode selection (Specialty/Direction/Mixed)
  - Quiz controls (stop, continue)
  - Navigation (back buttons)

### 5. Quiz Data Management (`quiz_data.py`)
- **Content**: Two question sets:
  - Specialty questions (15 items) - business strategy and innovation topics
  - Direction questions (30 items) - general management and economics topics
- **Logic**: Random question selection with source tracking
- **Features**: Mixed mode combining both question sets

## Data Flow

1. **User Interaction**: User sends command or clicks inline button
2. **Handler Processing**: Appropriate handler processes the request
3. **Database Operations**: User stats and quiz state updated in SQLite
4. **Question Selection**: Random question chosen based on selected mode
5. **Response Generation**: Bot sends question with appropriate keyboard
6. **Answer Validation**: User response checked against expected question number
7. **Statistics Update**: Performance metrics updated (streaks, totals, accuracy)

## External Dependencies

- **python-telegram-bot**: Main framework for Telegram bot development
- **SQLite3**: Built-in Python database (no external dependency)
- **Logging**: Built-in Python logging for debugging and monitoring

## Deployment Strategy

**Current Setup**: 
- Standalone Python application using long-polling
- SQLite database file stored locally
- Bot token configured via environment variable with hardcoded fallback

**Architecture Decisions**:
- **SQLite over external database**: Chosen for simplicity and minimal setup requirements
- **Long-polling over webhooks**: Simpler deployment without requiring HTTPS endpoint
- **Modular design**: Separation of concerns for maintainability
- **Context managers**: Ensures proper database connection handling and resource cleanup

**Pros of Current Approach**:
- Simple deployment (single process)
- No external database dependencies
- Self-contained application
- Easy to develop and debug locally

**Considerations for Production**:
- SQLite may need migration to PostgreSQL for multi-instance deployments
- Long-polling suitable for moderate traffic but webhooks preferred for high volume
- Current token fallback should be removed for security in production